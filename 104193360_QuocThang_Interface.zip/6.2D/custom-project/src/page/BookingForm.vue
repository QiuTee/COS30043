<template>
  <div>
    <the-resource></the-resource>
  </div>
</template>
<script>
import TheResource from "../components/learning-resource/TheResource.vue";
export default {
  components: {
    TheResource,
  },
};
</script>
